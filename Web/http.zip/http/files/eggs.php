<title>W&M exclusive robot</title>

<style>
    h1 {text-align:center}
    h2 {text-align:center}
    p {text-align:center}
</style>

<head>
    <body>
        <h1>Fully automatic rp system Easter eggs</h1>
        <h2>Wow you find me!</h2>
        <hr></hr>
        <p>So I will tell you my secret as a reward!</p>
        <p>That is how I make random num in show.php</p>
        <!-- Just MT19937! Ha ha! -->
    </body>
</head>