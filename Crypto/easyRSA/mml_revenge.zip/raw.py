from flag import flag
from Crypto.Util.number import *
msg1 = flag[:22]
msg2 = flag[22:]
m = bytes_to_long(msg1)
p = getPrime(512)
q = getPrime(512)
N = p * q
phi = (p-1) * (q-1)
while True:
    d = getRandomNBitInteger(200)
    if GCD(d, phi) == 1:
        e = inverse(d, phi)
        break

c = pow(m, e, N)

print(c, e, N, sep='\n')

flag2 = bytes_to_long(msg2)
p2 = getPrime(512)
q2 = getPrime(512)
N2 = p2*q2
e2 = 65537
print (pow(flag2,e2,N2))
print (e2,N2)
print (p2>>200)
